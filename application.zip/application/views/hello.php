<?php

echo "<a href='{base_url() . '/assets/'}'></a>";