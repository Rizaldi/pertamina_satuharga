<header class="site-header">
    <div class="container-fluid">

        <a href="#" class="site-logo">
            <label style="font-weight: bold;padding-right: 10px;">Dashboard Satu Harga</label>            
        </a>

        <button id="show-hide-sidebar-toggle" class="show-hide-sidebar">
            <span>toggle menu</span>
        </button>

        <button class="hamburger hamburger--htla">
            <span>toggle menu</span>
        </button>
    </div><!--.container-fluid-->
</header><!--.site-header-->

<div class="mobile-menu-left-overlay"></div>