<nav class="side-menu">
    <ul class="side-menu-list">
        <li class="blue">
            <a href="<?php echo site_url('home'); ?>">
                <i class="font-icon font-icon-chart-2"></i>
                <span class="lbl">Dashboard</span>
            </a>
        </li>
        <li class="blue">
            <a href="<?php echo site_url('spbu'); ?>">
                <i class="font-icon font-icon-chart-3"></i>
                <span class="lbl">SPBU</span>
            </a>
        </li>
        <li class="blue">
            <a href="<?php echo site_url('maps'); ?>">
                <i class="font-icon font-icon-map"></i>
                <span class="lbl">Maps</span>
            </a>
        </li>
        <li class="blue">
            <a href="<?php echo site_url('reports'); ?>">
                <i class="font-icon font-icon-chart"></i>
                <span class="lbl">Reports</span>
            </a>
        </li>
        <li class="blue">
            <a href="<?php echo site_url('reports/purchase'); ?>">
                <i class="font-icon font-icon-chart"></i>
                <span class="lbl">Data Pembelian</span>
            </a>
        </li>
        <li class="red">
            <a href="<?php echo site_url('login/logout'); ?>">
                <i class="glyphicon glyphicon-log-out"></i>
                <span class="lbl">Log out</span>
            </a>
        </li>
    </ul>

</nav><!--.side-menu-->