<?php

class Test {

	public function voice() {
		echo 'heloo';
	}
}